#include "stm32f10x.h"
#include "Display_EPD_W21_spi.h"
#include "Display_EPD_W21.h"
#include "Ap_29demo.h"	

ErrorStatus HSEStartUpStatus;

unsigned char HRES,VRES_byte1,VRES_byte2;

#define Source_Pixel  240    //  
#define Gate_Pixel    360    //
//

//#define OTP_Mode             // 
//#define Normal_TEST          //
//#define Auto_RUN             //
#define Partial_Display      //

#define PIC_WHITE                     0xFF  // 
#define PIC_BLACK                     0x00  //
#define PIC_Source_Line               0xAA  //
#define PIC_Gate_Line                 0x55  //
#define PIC_UP_BLACK_DOWN_WHITE       0xF0  //
#define PIC_LEFT_BLACK_RIGHT_WHITE    0x0F  //
#define PIC_Frame                     0x01  // 
#define PIC_Crosstalk                 0x02  //
#define PIC_Chessboard                0x03  //
#define PIC_Image                     0x04  //




/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);

//EPD
void EPD_init(void);
void EPD_init_data(void);
void EPD_OTP(void);

void PIC_display(unsigned char NUM);

void PIC_display1(const unsigned char* picData_old,const unsigned char* picData_new);
void PIC_display2(const unsigned char* picData);
void PIC_display_Clean(void);
void EPD_partial_display_Full(u16 x_start,u16 y_start,const unsigned char *new_data,unsigned int PART_COLUMN,unsigned int PART_LINE,unsigned char mode); //partial display 

void EPD_sleep(void);
void EPD_refresh(void);
void lcd_chkstatus(void);

//LUT
void lut(void);
///////////////////////////////////////

void driver_delay_us(unsigned int xus)  //1us
{
	for(;xus>1;xus--);
}

void driver_delay_xms(unsigned long xms) //1ms
{	
    unsigned long i = 0 , j=0;

    for(j=0;j<xms;j++)
	{
        for(i=0; i<256; i++);
    }
}
void DELAY_S(unsigned int delaytime)     //  1s
{
	int i,j,k;
	for(i=0;i<delaytime;i++)
  {
		for(j=0;j<4000;j++)           
		{
			for(k=0;k<222;k++);
                
		}
	}
}
void DELAY_M(unsigned int delaytime)     //  1M
{
	int i;
	for(i=0;i<delaytime;i++)
		DELAY_S(60);
}
/*******************************************************************************
* Function Name  : main
* Description    : Main program
* Input          : None
* Output         : None
* Return         : None
#define NVIC_VectTab_FLASH  misc.h
*******************************************************************************/



//Tips//
/*When the electronic paper is refreshed in _Full screen, the picture flicker is a normal phenomenon, and the main function is to clear the display afterimage in the previous picture.
  When the local refresh is performed, the screen does not flash.*/
/*When you need to transplant the driver, you only need to change the corresponding IO. The BUSY pin is the input mode and the others are the output mode. */
int	main(void)
{
			unsigned int i;
			RCC_Configuration();
			//GPIO setting
			GPIO_Configuration();
	

          #ifdef Partial_Display    
							{
								//Partial _Full screen refresh
								//EPD_Clean
							#if 1			
								EPD_W21_Init();             //Electronic paper IC reset
								PIC_display(PIC_WHITE);//EPD_picture
								EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!

								EPD_partial_display_Full(0,0,gImage_num[0],32,32,0);  //x,y,old_data,new_data,W,L,mode 
								EPD_partial_display_Full(8,32,gImage_num[1],32,32,0);  //x,y,old_data,new_data,W,L,mode 		
								EPD_partial_display_Full(16,64,gImage_num[2],32,32,0);  //x,y,old_data,new_data,W,L,mode 	
								EPD_partial_display_Full(24,96,gImage_num[3],32,32,0);  //x,y,old_data,new_data,W,L,mode 
								EPD_partial_display_Full(32,128,gImage_num[4],32,32,0);  //x,y,old_data,new_data,W,L,mode 	
								EPD_partial_display_Full(0,160,gImage_num[5],32,32,0);  //x,y,old_data,new_data,W,L,mode 		
								EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!

								EPD_partial_display_Full(0,0,gImage_num[0],32,32,1);  //x,y,old_data,new_data,W,L,mode 
								EPD_partial_display_Full(8,32,gImage_num[1],32,32,1);  //x,y,old_data,new_data,W,L,mode 		
								EPD_partial_display_Full(16,64,gImage_num[2],32,32,1);  //x,y,old_data,new_data,W,L,mode 	
								EPD_partial_display_Full(24,96,gImage_num[3],32,32,1);  //x,y,old_data,new_data,W,L,mode 
								EPD_partial_display_Full(32,128,gImage_num[4],32,32,1);  //x,y,old_data,new_data,W,L,mode 	
								EPD_partial_display_Full(0,160,gImage_num[5],32,32,1);  //x,y,old_data,new_data,W,L,mode 		
								EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!

								//EPD_Clean
								EPD_W21_Init();        //Electronic paper IC reset
								PIC_display(PIC_WHITE);//EPD_picture
								
								EPD_sleep();//EPD_sleep,Sleep instruction is necessary, please do not delete!!!
								EPD_W21_WriteCMD(0x03);			// Power off
								EPD_W21_WriteDATA(0x00);    //POWER OFF SEQUENCE SETTING (PFS)
								EPD_W21_WriteCMD(0x02);			// Power off
								while(1);
						  #endif
	         }
          #endif  //end Partial_Display	
								
							
							
}		

void EPD_init(void)
{

#if 1

HRES=0xf0;					 //0xf0=240
VRES_byte1=0x01;		 //0x01,0xa0=360
VRES_byte2=0x68;


EPD_W21_Init();             //Electronic paper IC reset

EPD_W21_WriteCMD(0x00);			// panel setting   PSR
EPD_W21_WriteDATA(0xFF);			// RES1 RES0 REG KW/R     UD    SHL   SHD_N  RST_N	 0xFF=LUT from register,0xDF=LUT from OTP. (Default)
EPD_W21_WriteDATA(0x0D);			// x x x VCMZ TS_AUTO TIGE NORG VC_LUTZ

EPD_W21_WriteCMD(0x01);			// POWER SETTING   PWR
EPD_W21_WriteDATA(0x03);			//  x x x x x x VDS_EN VDG_EN	
EPD_W21_WriteDATA(0x10);			//  x x x VCOM_SLWE VGH[3:0]   VGH=20V, VGL=-20V	
EPD_W21_WriteDATA(0x3F);			//  x x VSH[5:0]	VSH = 15V
EPD_W21_WriteDATA(0x3F);			//  x x VSL[5:0]	VSL=-15V
EPD_W21_WriteDATA(0x14);			//  OPTEN VDHR[6:0]  VHDR=6.4V

EPD_W21_WriteCMD(0x03);			// POWER OFF sequence setting    PFS
EPD_W21_WriteDATA(0x00);			// x x T_VDS_OFF[1:0] x x x x 	
							// T_VDS_OFF[1:0] 00=1 frame; 01=2 frame; 10=3 frame; 11=4 frame

EPD_W21_WriteCMD(0x06);			// booster soft start   BTST 
EPD_W21_WriteDATA(0x17);			//  BT_PHA[7:0]  	
EPD_W21_WriteDATA(0x17);			//  BT_PHB[7:0]	
EPD_W21_WriteDATA(0x17);			//  x x BT_PHC[5:0]	

EPD_W21_WriteCMD(0x2A);			// LUT Option LUTOPT
EPD_W21_WriteDATA(0x00);			// EOTP ESO x x x x x x
EPD_W21_WriteDATA(0x00);			// STATE_XON[7:0]  	
EPD_W21_WriteDATA(0x00);			// STATE_XON[15:8]
EPD_W21_WriteDATA(0xFF);			// GROUP_KWE[7:0]
EPD_W21_WriteDATA(0x00);			// x x x x x ATRED NORED

EPD_W21_WriteCMD(0x30);			// pll control  	PLL 
EPD_W21_WriteDATA(0x09);			// x x x x FRS[4:0]  	frame rate = 50HZ

EPD_W21_WriteCMD(0x50);			// VCOM and Data interval setting 	CDI 
EPD_W21_WriteDATA(0xD7);			// VBD[1:0] DDX[1:0] CDI[3:0]

EPD_W21_WriteCMD(0x60);			// TCON setting			TCON 
EPD_W21_WriteDATA(0x22);			// S2G[3:0] G2S[3:0]   non-overlap = 12		

EPD_W21_WriteCMD(0x61);			// resoultion setting 
EPD_W21_WriteDATA(HRES);			//  HRES[7:3] 0 0 0	
EPD_W21_WriteDATA(VRES_byte1);			//  x x x x x x x VRES[8]	
EPD_W21_WriteDATA(VRES_byte2);			//  VRES[7:0]

EPD_W21_WriteCMD(0x65);			// gate/source start setting 	GSST
EPD_W21_WriteDATA(0x00);			//  HST[7:3] 0 0 0	
EPD_W21_WriteDATA(0x00);			//  x x x x x x x VST[8]	
EPD_W21_WriteDATA(0x00);			//  VST[7:0]		

EPD_W21_WriteCMD(0x82);			// VCOM_DC setting		VDCS 
EPD_W21_WriteDATA(0x08);			// x  VDCS[6:0]	VCOM_DC value= -1.9v    00~3f,0x12=-1.9v

EPD_W21_WriteCMD(0xe3);			// power saving			PWS 
EPD_W21_WriteDATA(0x88);			// VCOM_W[3:0] SD_W[3:0]

lut(); //LUT settings
//PIC_display(PIC_WHITE);
#endif
}


void EPD_init_data(void)
{
	
	
#if 1

	  HRES=0xf0;					 //0xf0=240
	  VRES_byte1=0x01;		 //0x01,0xa0=416
	  VRES_byte2=0x68;
	
	
	//EPD_W21_Init();             //Electronic paper IC reset
	
	EPD_W21_WriteCMD(0x00);			// panel setting   PSR
	EPD_W21_WriteDATA(0xFF);			// RES1 RES0 REG KW/R     UD    SHL   SHD_N  RST_N	
	EPD_W21_WriteDATA(0x0D);			// x x x VCMZ TS_AUTO TIGE NORG VC_LUTZ
	
	EPD_W21_WriteCMD(0x01);			// POWER SETTING   PWR
	EPD_W21_WriteDATA(0x03);			//  x x x x x x VDS_EN VDG_EN	
	EPD_W21_WriteDATA(0x10);			//  x x x VCOM_SLWE VGH[3:0]   VGH=20V, VGL=-20V	
	EPD_W21_WriteDATA(0x3F);			//  x x VSH[5:0]	VSH = 15V
	EPD_W21_WriteDATA(0x3F);			//  x x VSL[5:0]	VSL=-15V
	EPD_W21_WriteDATA(0x14);			//  OPTEN VDHR[6:0]  VHDR=6.4V

	EPD_W21_WriteCMD(0x03);			// POWER OFF sequence setting    PFS
	EPD_W21_WriteDATA(0x00);			// x x T_VDS_OFF[1:0] x x x x 	
									              // T_VDS_OFF[1:0] 00=1 frame; 01=2 frame; 10=3 frame; 11=4 frame

	EPD_W21_WriteCMD(0x06);			// booster soft start   BTST 
	EPD_W21_WriteDATA(0x17);			//  BT_PHA[7:0]  	
	EPD_W21_WriteDATA(0x17);			//  BT_PHB[7:0]	
	EPD_W21_WriteDATA(0x17);			//  x x BT_PHC[5:0]	
	
	EPD_W21_WriteCMD(0x2A);			// LUT Option LUTOPT
	EPD_W21_WriteDATA(0x00);			// EOTP ESO x x x x x x
	EPD_W21_WriteDATA(0x00);			// STATE_XON[7:0]  	
	EPD_W21_WriteDATA(0x00);			// STATE_XON[15:8]
	EPD_W21_WriteDATA(0xFF);			// GROUP_KWE[7:0]
	EPD_W21_WriteDATA(0x00);			// x x x x x ATRED NORED
	
	EPD_W21_WriteCMD(0x30);			// pll control  	PLL 
	EPD_W21_WriteDATA(0x09);			// x x x x FRS[4:0]  	frame rate = 50HZ

	EPD_W21_WriteCMD(0x50);			// VCOM and Data interval setting 	CDI 
	EPD_W21_WriteDATA(0xD7);			// VBD[1:0] DDX[1:0] CDI[3:0]

	EPD_W21_WriteCMD(0x60);			// TCON setting			TCON 
	EPD_W21_WriteDATA(0x22);			// S2G[3:0] G2S[3:0]   non-overlap = 12		

	EPD_W21_WriteCMD(0x61);			// resoultion setting 
	EPD_W21_WriteDATA(HRES);			//  HRES[7:3] 0 0 0	
	EPD_W21_WriteDATA(VRES_byte1);			//  x x x x x x x VRES[8]	
	EPD_W21_WriteDATA(VRES_byte2);			//  VRES[7:0]
	
	EPD_W21_WriteCMD(0x65);			// gate/source start setting 	GSST
	EPD_W21_WriteDATA(0x00);			//  HST[7:3] 0 0 0	
	EPD_W21_WriteDATA(0x00);			//  x x x x x x x VST[8]	
	EPD_W21_WriteDATA(0x00);			//  VST[7:0]		
	
	EPD_W21_WriteCMD(0x82);			// VCOM_DC setting		VDCS 
	EPD_W21_WriteDATA(0x08);			// x  VDCS[6:0]	VCOM_DC value= -1.9v    00~3f,0x12=-1.9v

	EPD_W21_WriteCMD(0xe3);			// power saving			PWS 
	EPD_W21_WriteDATA(0x88);			// VCOM_W[3:0] SD_W[3:0]
	
	lut(); //LUT settings
	//PIC_display_Clear();
	#endif
	
}




void EPD_OTP(void)
{
unsigned int i;

EPD_W21_Init();//Electronic paper IC reset
driver_delay_xms(50);	
EPD_W21_WriteCMD(0xA0);   
EPD_W21_WriteCMD(0x10);		
	

/********************************************************/

for(i=0;i<8192;i++)
{
		EPD_W21_WriteDATA(OTP_Code[i]);
}

//**************** ����OTP ******************************/	
EPD_W21_WriteCMD(0x01);
EPD_W21_WriteDATA(0x83);  //�����ڲ�VPP
EPD_W21_WriteDATA(0x10);
EPD_W21_WriteDATA(0x1E);  // VSH = +8.4V
EPD_W21_WriteDATA(0x1E);  // VSL = -8.4V
EPD_W21_WriteDATA(0x0D);  //0x0D-->0x14

EPD_W21_WriteCMD(0x06);
EPD_W21_WriteDATA(0x17);
EPD_W21_WriteDATA(0x17);
EPD_W21_WriteDATA(0x17);

EPD_W21_WriteCMD(0x04);
lcd_chkstatus();
driver_delay_xms(100);
EPD_W21_WriteCMD(0xA1);        	
lcd_chkstatus();
driver_delay_xms(100);
EPD_W21_WriteCMD(0x02);
lcd_chkstatus();				
EPD_W21_WriteCMD(0xA2);	
EPD_W21_Init();//Electronic paper IC reset
}








void EPD_refresh(void)
{
	  EPD_W21_WriteCMD(0x04);			//power on 		
	  lcd_chkstatus();
		EPD_W21_WriteCMD(0x12);			//DISPLAY REFRESH 	
	
	
	
		driver_delay_xms(10);	    //!!!The delay here is necessary, 200uS at least!!!     
		lcd_chkstatus();
}	
void EPD_sleep(void)
{
		EPD_W21_WriteCMD(0X50);
		EPD_W21_WriteDATA(0xf7);	
		EPD_W21_WriteCMD(0X02);  	//power off
	  lcd_chkstatus();
		EPD_W21_WriteCMD(0X07);  	//deep sleep
		EPD_W21_WriteDATA(0xA5);

}

//LUT download
void lut(void)
{
	unsigned int count;	 
	{
		EPD_W21_WriteCMD(0x20);							//vcom
		for(count=0;count<42;count++)
			{EPD_W21_WriteDATA(lut_vcom[count]);}
		
	  EPD_W21_WriteCMD(0x21);							//red not use
	  for(count=0;count<42;count++)
		  {EPD_W21_WriteDATA(lut_ww[count]);}

		EPD_W21_WriteCMD(0x22);							//bw r
		for(count=0;count<42;count++)
			{EPD_W21_WriteDATA(lut_bw[count]);}

		EPD_W21_WriteCMD(0x23);							//wb w
		for(count=0;count<42;count++)
			{EPD_W21_WriteDATA(lut_wb[count]);}

		EPD_W21_WriteCMD(0x24);							//bb b
		for(count=0;count<42;count++)
			{EPD_W21_WriteDATA(lut_bb[count]);}

	}	         
}

void PIC_display1(const unsigned char* picData_old,const unsigned char* picData_new)
{
    unsigned int i;
		EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	{
	  EPD_W21_WriteDATA(*picData_old);
	  picData_old++;
	}
		EPD_W21_WriteCMD(0x13);		     //Transfer new data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	{
	  EPD_W21_WriteDATA(*picData_new);
	  picData_new++;
	}
	
	EPD_refresh();

}

void PIC_display2(const unsigned char* picData)
{
    unsigned int i;
	
		EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	  EPD_W21_WriteDATA(0x00); 
	
	
		EPD_W21_WriteCMD(0x13);		     //Transfer new data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	{
	  EPD_W21_WriteDATA(*picData);
	  picData++;
	}

EPD_W21_WriteCMD(0x17);			//DISPLAY REFRESH 		
EPD_W21_WriteDATA(0xA5);
		
}

void PIC_display(unsigned char NUM)
{
	
	
 unsigned int i,row, column;
 unsigned int pcnt;

  pcnt = 0;    
	
	
	EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	   {
	      EPD_W21_WriteDATA(0x00);
	   }
	
	
	EPD_W21_WriteCMD(0x13);		     //Transfer new data
	
  for(column=0; column<Gate_Pixel; column++)   
  {
    for(row=0; row<Source_Pixel/8; row++)  
    {
      switch (NUM)
      {
        case PIC_WHITE:
          EPD_W21_WriteDATA(0xFF);
          break;  
				
        case PIC_BLACK:
          EPD_W21_WriteDATA(0x00);
          break;  
				
        case PIC_Source_Line:
          EPD_W21_WriteDATA(0xAA);  
         break;
				
        case PIC_Gate_Line:
          if(column%2)
             EPD_W21_WriteDATA(0xff); //����Gate��
          else
             EPD_W21_WriteDATA(0x00); //ż��Gate��
         break;			
				
			 case PIC_Chessboard:
          if(row>=(Source_Pixel/8/2)&&column>=(Gate_Pixel/2))
             EPD_W21_WriteDATA(0xff);
          else if(row<(Source_Pixel/8/2)&&column<(Gate_Pixel/2))
             EPD_W21_WriteDATA(0xff);										
          else
             EPD_W21_WriteDATA(0x00);
           break; 			
				
			 case PIC_LEFT_BLACK_RIGHT_WHITE:
          if(row>=(Source_Pixel/8/2))
             EPD_W21_WriteDATA(0xff);
          else
             EPD_W21_WriteDATA(0x00);
           break;
					
       case PIC_UP_BLACK_DOWN_WHITE:
          if(column>=(Gate_Pixel/2))
				     EPD_W21_WriteDATA(0xFF);
			    else
				     EPD_W21_WriteDATA(0x00);
			    break;
					
       case PIC_Frame:
				  if(column==0||column==(Gate_Pixel-1))
            EPD_W21_WriteDATA(0x00);						
          else if(row==0)
            EPD_W21_WriteDATA(0x7F);
					else if(row==(Source_Pixel/8-1))
            EPD_W21_WriteDATA(0xFE);					
          else
            EPD_W21_WriteDATA(0xFF);
          break; 					
					
       case PIC_Crosstalk:
          if((row>=(Source_Pixel/8/3)&&row<=(Source_Pixel/8/3*2)&&column<=(Gate_Pixel/3))||(row>=(Source_Pixel/8/3)&&row<=(Source_Pixel/8/3*2)&&column>=(Gate_Pixel/3*2)))
            EPD_W21_WriteDATA(0x00);
          else
            EPD_W21_WriteDATA(0xFF);
          break; 					
					
       case PIC_Image:
          EPD_W21_WriteDATA(gImage_1[pcnt++]);
          break;  
                                
        default:
          break;
      }
    }
  }	
	
	EPD_W21_WriteCMD(0x17);			//DISPLAY REFRESH 		
  EPD_W21_WriteDATA(0xA5);
	lcd_chkstatus();
	
}

void PIC_display_Clean(void)
{
    unsigned int i;
		EPD_W21_WriteCMD(0x10);	       //Transfer old data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	{
	  EPD_W21_WriteDATA(0xff);
	}
	
		EPD_W21_WriteCMD(0x13);		     //Transfer new data
	  for(i=0;i<(Gate_Pixel*Source_Pixel/8);i++)	     
	{
	  EPD_W21_WriteDATA(0xff);
	}
	EPD_refresh();
}

void lcd_chkstatus(void)
{
	unsigned char busy;
	do
	{
		EPD_W21_WriteCMD(0x71);
		busy = isEPD_W21_BUSY;
		busy =!(busy & 0x01);        
	}
	while(busy);   
	driver_delay_xms(200);                       
}




/***************************partial display function*************************************/
void EPD_partial_display_Full(u16 x_start,u16 y_start,const unsigned char *new_data,unsigned int PART_COLUMN,unsigned int PART_LINE,unsigned char mode) //partial display 
{
	unsigned int i,count;  
	unsigned int x_end,y_start1,y_start2,y_end1,y_end2;
	x_start=x_start;//ת��Ϊ�ֽ�
	x_end=x_start+PART_LINE-1; 
	
	y_start1=0;
	y_start2=y_start;
	if(y_start>=256)
	{
		y_start1=y_start2/256;
		y_start2=y_start2%256;
	}
	y_end1=0;
	y_end2=y_start+PART_COLUMN-1;
	if(y_end2>=256)
	{
		y_end1=y_end2/256;
		y_end2=y_end2%256;		
	}		
	
  count=PART_COLUMN*PART_LINE/8;

	  EPD_init(); //EPD init
	  EPD_W21_WriteCMD(0x91);		//This command makes the display enter partial mode
		EPD_W21_WriteCMD(0x90);		//resolution setting
		EPD_W21_WriteDATA (x_start);   //x-start     
		EPD_W21_WriteDATA (x_end);	 //x-end	

		EPD_W21_WriteDATA (y_start1);
		EPD_W21_WriteDATA (y_start2);   //y-start    
		
		EPD_W21_WriteDATA (y_end1);		
		EPD_W21_WriteDATA (y_end2);  //y-end
		EPD_W21_WriteDATA (0x28);	

		EPD_W21_WriteCMD(0x10);	       //writes Old data to SRAM for programming
 
	for(i=0;i<count;i++)	     
	{
	 EPD_W21_WriteDATA(0x00);  
	}
	
	if(mode==0)
	{
	EPD_W21_WriteCMD(0x13);				 //writes New data to SRAM.
		for(i=0;i<count;i++)	     
	 {
		EPD_W21_WriteDATA(new_data[i]); //ͼƬ  
	 }
 }
	else if(mode==1)
	{
	EPD_W21_WriteCMD(0x13);				 //writes New data to SRAM.
		for(i=0;i<count;i++)	     
	 {
		EPD_W21_WriteDATA(0xff);  //ȫ��
	 }
 }		
	else if(mode==2)
	{
	EPD_W21_WriteCMD(0x13);				 //writes New data to SRAM.
		for(i=0;i<count;i++)	     
	 {
		EPD_W21_WriteDATA(0x00);  //ȫ��
	 }
 }	 
	

   EPD_init_data();//ȫˢ��ʼ��������λ	
   EPD_refresh();//EPD_refresh	
	
	  
}


/***********************************************************
						end file
***********************************************************/

/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
 
  // Reset RCC clock configuration
  RCC_DeInit();
 
  // Enable external crystal
  RCC_HSEConfig(RCC_HSE_ON);
  
  // Waiting for the external crystal to stabilize
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if(HSEStartUpStatus == SUCCESS)
  {
    // Set the phase-locked loop frequency PLLCLK = 8MHz * 9 = 72 MHz
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
  }
  else {
    // Enable internal crystal
    RCC_HSICmd(ENABLE);
    // Waiting for the internal crystal to stabilize
    while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);

    // Set the phase-locked loop frequency PLLCLK = 8MHz/2 * 16 = 64 MHz 
    RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_16);
  }

    // Enable flash prefetch cache
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

  //Set the code delay, FLASH_Latency_2 is two delay cycles
  FLASH_SetLatency(FLASH_Latency_2);
	
  //Set the system total clock
  RCC_HCLKConfig(RCC_SYSCLK_Div1); 

  //Set the high speed device total clock, RCC_HCLK_Div1 is the system clock divided by 1
  RCC_PCLK2Config(RCC_HCLK_Div1); 

  //Set the low speed device total clock, RCC_HCLK_Div2 is the system clock divided by 2
  RCC_PCLK1Config(RCC_HCLK_Div2);
  
  //Enable phase-locked loop multiplier
  RCC_PLLCmd(ENABLE);
  
  // Waiting for the frequency of the phase-locked loop to multiply after frequency stabilization
  while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
  
  // Select the phase-locked loop clock as the system clock
  RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
  
  // Waiting for setup to complete
  while(RCC_GetSYSCLKSource() != 0x08);
    
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
            RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO,
            ENABLE);

}

/*******************************************************************************
* Function name  : GPIO_Configuration
* Description         : Set the GPIO pin parameters used by the SPI serial port.
* Input        : None
* Output        : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);
	  				     	
	
	 //CS-->PD8   SCK-->PD9  SDO--->PD10 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOD, &GPIO_InitStructure);	  	
	
	
	
	 // D/C--->PE15	   RES-->PE14
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14|GPIO_Pin_15;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);	  				     		
	
	// BUSY--->PE13
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;	//Pull up input
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
 	GPIO_Init(GPIOE, &GPIO_InitStructure);				//Initialize GPIO
	
	 //LED
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}
/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{ 
  //NVIC_InitTypeDef NVIC_InitStructure;
  ;
}


#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif






